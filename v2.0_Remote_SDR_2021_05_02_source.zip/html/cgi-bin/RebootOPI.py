#!/usr/bin/python3



import os



os.system("reboot")


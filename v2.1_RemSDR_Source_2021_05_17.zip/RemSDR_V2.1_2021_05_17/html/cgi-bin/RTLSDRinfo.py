#!/usr/bin/python3



import os



os.system("rtl_eeprom 2>&1")

